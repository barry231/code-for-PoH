import numpy as np
import importlib
import time
from numba import jit

import random
import types
import warnings
import sys

from numba.core.errors import NumbaDeprecationWarning, NumbaPendingDeprecationWarning
import warnings

warnings.simplefilter('ignore', category=NumbaDeprecationWarning)
warnings.simplefilter('ignore', category=NumbaPendingDeprecationWarning)
warnings.filterwarnings("ignore", message="loaded more than 1 DLL from .libs", category=UserWarning)
import re
from datasets import load_dataset
from .base_task import BaseTask
import numpy as np
import json
import random
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from numba import jit
import pickle as pkl
from .evaluation import Evaluation
import sys
import types
import warnings
import numpy as np
import time
import os
import types
import warnings
import sys
import importlib
import random
import logging
from .gen_inst import TSPInstance, load_dataset
from .gls import guided_local_search
import time
import elkai
from tqdm import tqdm
def convert_to_int(value):
    try:
        return int(value)
    except ValueError:
        return None
def save_solution_to_json(data, solution_data, filename='solution.json'):
    output_data = {
        'locations': data['locations'],
        'solution': solution_data
    }
    with open(filename, 'w') as f:
        json.dump(output_data, f, indent=4)
class CustomTask(BaseTask):
    def __init__(self,
                 train_size,
                 eval_size,
                 test_size=None,
                 task_name='tsp',
                 task_discription="",
                 seed=None,
                 post_instruction=True,
                 **kwargs):
        super().__init__(task_name=task_name,
                         task_discription=task_discription,
                         seed=seed,
                         train_size=train_size,
                         eval_size=eval_size,
                         test_size=test_size,
                         post_instruction=post_instruction,
                         )
        self.answer_format_prompt = f"""
            The output of the routes in the following format example :
            <<start>>
            """
        self.answer_format_prompt += f"Salesman: 0-1-2-3-4-5-6-7-8-9-10-11-12-13-14\n"
        self.answer_format_prompt += "<<end>>\n\n"
        """
            answer_format_prompt: 
                It is appended after the task question to help the model extract the prediction.
                It should match your prediction extraction method in function "clean_response".
        """
        self.ndelay = 1
        self.problem_size = 200
        self.neighbor_size = np.minimum(200, self.problem_size)
        self.n_instance = 64
        self.running_time = 10
        self.old_route_set = set()
        self.distance_set=set()
        self.old_route_str=[]
        self.n_inst_eva = 3  # a small number of instances for test only
        self.iter_max = 1000  # number of iterations in GLS
        self.time_max = 30  # maximum time for each instance
        self.tasks_val, self.machines_val, self.tasks = self.read_instances()
    def load_task_dataset(self, data_dir):
        '''
            <task specific>
        '''
        with open('./src/tsp.json', 'r') as file:
            json_data = json.load(file)
        self.task_description = json_data['description']
        return json_data

    def transform_format(self, data):
        original_examples = data['examples']
        examples = []
        # Extracting input and target scores
        for example in original_examples:
            question = example['input']
            # Formatting the output
            formatted_example = {
                'question': question
            }
            examples.append(formatted_example)
        return examples
    def clean_response(self,response):
        function_pattern = r"```python(.*?)```"
        algorithm_str = re.search(r'<start>(.*?)<end>', response, re.DOTALL)
        matches = re.findall(function_pattern, response, re.DOTALL)
        print(matches)
        if matches:
            extracted_function = matches[0].strip()
            print(extracted_function)
        else:
            extracted_function = ""
            return 0,extracted_function
        gap=self.evaluate(extracted_function)
        if gap>=1000000:
            return 0,extracted_function
        return 1-(gap-3400)/200,extracted_function
    def cal_metric(self, preds):
        '''
        <task specific>
        Calculate the evaluation metric, e.g. Accuracy, F1 score.
        "question" is for NCBI calculating F1 score.
        return a number / tuple of metrics

        This function is for calculating the reward of MCTS.
        '''
        correct = self.cal_correct(preds=preds)
        a=0
        for i in range(len(correct)):
            if correct[i]!=0:
                a+=np.array(preds)[i]
        a=a/len(correct)
        return a
    def cal_reward(self, preds, questions=None):
        '''
        <task specific>
        Calculate the evaluation metric, e.g. Accuracy, F1 score.
        "question" is for NCBI calculating F1 score.
        return a number / tuple of metrics

        This function is for calculating the reward of MCTS.
        '''
        correct = self.cal_correct(preds=preds)
        a=[]
        for i in range(len(correct)):
            if correct[i]!=0:
                a.append(np.array(preds)[i])
            else:
                a.append(0)
        return a
    def cal_correct(self, preds, data_type="str"):
        '''
        <task specific>
        The function of comparing the predictions and labels.

        data_type: str | set
            str: preds, labels are List(str)
            set: preds, labels are List(set)

        Every time a batch data is sampled and predicted, by comparing with
        the labels, PromptAgent collect the errors.
        Function called at: prompt_optim_agent/world_model/gradient_descent.py line 54

        '''
        if data_type == "set":
            comparisons = []
            for p, l in zip(preds):
                if p == l:
                    comparisons.append(1)
                else:
                    comparisons.append(0)
                return comparisons
        else:
            return list(np.array((np.array(preds) != 0)).astype(int))

    def ls(self, tasks_val, tasks, machines_val):
        pi0, cmax0 = self.neh(tasks, machines_val, tasks_val)
        # print("neh results: ",cmax0)
        pi = pi0
        cmax_old = cmax0
        while True:
            # piprim = local_search(pi, tasks_val)
            piprim = local_search(pi, cmax_old, tasks, machines_val)
            cmax = makespan(piprim, tasks, machines_val)
            if (cmax >= cmax_old):
                break
            else:
                pi = piprim
                cmax_old = cmax
        return pi, cmax_old

    ############################################### Iterated Local Search ####################################################
    def gls(self, heuristic):

        cmax_best_list = np.zeros(self.n_inst_eva)

        n_inst = 0
        for tasks_val, tasks, machines_val in zip(self.tasks_val, self.tasks, self.machines_val):

            cmax_best = 1E10
            random.seed(2024)
            # print("run ...")
            try:
                pi, cmax = self.neh(tasks, machines_val, tasks_val)
                n = len(pi)

                pi_best = pi
                cmax_best = cmax
                n_itr = 0
                time_start = time.time()
                while time.time() - time_start < self.time_max and n_itr < self.iter_max:
                    # piprim = local_search(pi, tasks_val)
                    piprim = local_search(pi, cmax, tasks, machines_val)

                    pi = piprim
                    cmax = makespan(pi, tasks, machines_val)

                    if (cmax < cmax_best):
                        pi_best = pi
                        cmax_best = cmax

                    tasks_perturb, jobs = heuristic.get_matrix_and_jobs(pi, tasks.copy(), machines_val, n)

                    if (len(jobs) <= 1):
                        print("jobs is not a list of size larger than 1")
                        return 1E10
                    if (len(jobs) > 5):
                        jobs = jobs[:5]

                    cmax = makespan(pi, tasks_perturb, machines_val)

                    pi = local_search_perturb(pi, cmax, tasks_perturb, machines_val, jobs)

                    n_itr += 1
                    # print(f"it {n_itr} , cmax {cmax_best}")
                    if n_itr % 50 == 0:
                        pi = pi_best
                        cmax = cmax_best

            except Exception as e:
                # print("Error:", str(e))  # Print the error message
                cmax_best = 1E10

            # print(cmax_best)
            cmax_best_list[n_inst] = cmax_best
            n_inst += 1
            if n_inst == self.n_inst_eva:
                break

        return np.average(cmax_best_list)

    ###################################################################### NEH ############################################
    def sum_and_order(self, tasks_val, machines_val, tasks):
        tab = []
        tab1 = []
        for i in range(0, tasks_val):
            tab.append(0)
            tab1.append(0)
        for j in range(0, tasks_val):
            for k in range(0, machines_val):
                tab[j] += tasks[j][k]
        tmp_tab = tab.copy()
        place = 0
        iter = 0
        while (iter != tasks_val):
            max_time = 1
            for i in range(0, tasks_val):
                if (max_time < tab[i]):
                    max_time = tab[i]
                    place = i
            tab[place] = 1
            tab1[iter] = place
            iter = iter + 1
        return tab1

    def insertNEH(self, sequence, position, value):
        new_seq = sequence[:]
        new_seq.insert(position, value)
        return new_seq

    def neh(self, tasks, machines_val, tasks_val):
        order = self.sum_and_order(tasks_val, machines_val, tasks)
        current_seq = [order[0]]
        for i in range(1, tasks_val):
            min_cmax = float("inf")
            for j in range(0, i + 1):
                tmp = self.insertNEH(current_seq, j, order[i])
                cmax_tmp = makespan(tmp, tasks, machines_val)
                if min_cmax > cmax_tmp:
                    best_seq = tmp
                    min_cmax = cmax_tmp
            current_seq = best_seq
        return current_seq, makespan(current_seq, tasks, machines_val)

    def read_instances(self):
        tasks_val_list = []
        machines_val_list = []
        tasks_list = []

        for i in range(1, 65):
            filename = "./src/tasks/trainingdata/" + str(i) + ".txt"
            file = open(filename, "r")

            tasks_val, machines_val = file.readline().split()
            tasks_val = int(tasks_val)
            machines_val = int(machines_val)

            tasks = np.zeros((tasks_val, machines_val))
            for i in range(tasks_val):
                tmp = file.readline().split()
                for j in range(machines_val):
                    tasks[i][j] = int(float(tmp[j * 2 + 1]))

            tasks_val_list.append(tasks_val)
            machines_val_list.append(machines_val)
            tasks_list.append(tasks)

            file.close()

        return tasks_val_list, machines_val_list, tasks_list

    # def evaluate(self):
    #     time.sleep(1)
    #     try:
    #         res = Parallel(n_jobs=4, timeout=self.time_max*1.1)(delayed(self.gls)(x, y, z, a) for x, y, z , a in zip(self.tasks_val, self.tasks, self.machines_val,[None]*len(self.tasks_val)))
    #         #print(res)
    #         #print("check")
    #         #print("Average cmax = ",np.mean(res))
    #         return np.mean(res)
    #     except Exception as e:
    #         #print("Error:",str(e))
    #         return None

    def evaluate(self, code_string):
        try:
            # Suppress warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")

                # Create a new module object
                heuristic_module = types.ModuleType("heuristic_module")

                # Execute the code string in the new module's namespace
                exec(code_string, heuristic_module.__dict__)

                # Add the module to sys.modules so it can be imported
                sys.modules[heuristic_module.__name__] = heuristic_module

                # print(code_string)
                fitness = self.gls(heuristic_module)

                return fitness

        except Exception as e:
            # print("Error:", str(e))
            return None
@jit(nopython=True)
def makespan(order, tasks, machines_val):
    times = []
    for i in range(0, machines_val):
        times.append(0)
    for j in order:
        times[0] += tasks[j][0]
        for k in range(1, machines_val):
            if times[k] < times[k-1]:
                times[k] = times[k-1]
            times[k] += tasks[j][k]
    return max(times)


@jit(nopython=True)
def local_search(sequence, cmax_old,tasks,machines_val):
    new_seq = sequence[:]
    for i in range(len(new_seq)):
        for j in range(i+1, len(new_seq)):
            temp_seq = new_seq[:]
            temp_seq[i], temp_seq[j] = temp_seq[j], temp_seq[i]
            cmax = makespan(temp_seq, tasks, machines_val)
            if cmax < cmax_old:  # Assuming cmax_old is defined in sim_ann1 function
                new_seq = temp_seq[:]
                cmax_old = cmax
                #print(cmax)

    for i in range(1,len(new_seq)):
        for j in range(1,len(new_seq)):
            temp_seq = new_seq[:]
            temp_seq.remove(i)
            temp_seq.insert(j, i)
            cmax = makespan(temp_seq, tasks, machines_val)
            if cmax < cmax_old:  # Assuming cmax_old is defined in sim_ann1 function
                new_seq = temp_seq[:]
                cmax_old = cmax
                #print(cmax)

    return new_seq

@jit(nopython=True)
def local_search_perturb(sequence, cmax_old,tasks,machines_val,job):
    new_seq = sequence[:]
    for i in job:
        for j in range(i+1, len(new_seq)):
            temp_seq = new_seq[:]
            temp_seq[i], temp_seq[j] = temp_seq[j], temp_seq[i]
            cmax = makespan(temp_seq, tasks, machines_val)
            if cmax < cmax_old:  # Assuming cmax_old is defined in sim_ann1 function
                new_seq = temp_seq[:]
                cmax_old = cmax
                #print(cmax)

    for i in job:
        for j in range(1,len(new_seq)):
            temp_seq = new_seq[:]
            temp_seq.remove(i)
            temp_seq.insert(j, i)
            cmax = makespan(temp_seq, tasks, machines_val)
            if cmax < cmax_old:  # Assuming cmax_old is defined in sim_ann1 function
                new_seq = temp_seq[:]
                cmax_old = cmax
                #print(cmax)

    return new_seq



    

