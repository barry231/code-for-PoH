from openai import OpenAI
import time


class OpenAIModel():
    def __init__(
        self,
        model_name: str,
        api_key: str,
        temperature: float,
        **kwargs):

        self.model = OpenAI(
    base_url="https://xiaoai.plus/v1",
    # sk-xxx替换为自己的key
    api_key="sk-EmqRodGnY7wXx7JZZtPeEg1D9oQDreWoegN1XUQp15uyNcaE"
)

        self.model_name = "gpt-4-0125-preview"
        self.temperature = temperature
        
        self.batch_forward_func = self.batch_forward_chatcompletion
        self.generate = self.gpt_chat_completion

        
    
    def batch_forward_chatcompletion(self, batch_prompts,batch_size):
        """
        Input a batch of prompts to openai chat API and retrieve the answers.
        """
        responses = []
        for i in range(batch_size):
            response = self.gpt_chat_completion(prompt=batch_prompts)
            responses.append(response)
        return responses
    
    
    def gpt_chat_completion(self, prompt):
        messages = [{"role": "user", "content": prompt},]
        backoff_time = 1
        while True:
            try:
                return self.model.chat.completions.create(
                    messages=messages,
                    model=self.model_name,
                    temperature=self.temperature).choices[0].message.content.strip()
            except Exception as e:
                print(e, f' Sleeping {backoff_time} seconds...')
                time.sleep(backoff_time)
                backoff_time *= 1.5

        
    
        
        