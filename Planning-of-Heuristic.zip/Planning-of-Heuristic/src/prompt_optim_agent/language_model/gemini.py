import requests
import time
from zhipuai import ZhipuAI
import os
import google.generativeai as genai
proxy_url = 'http://127.0.0.1'
proxy_port = '7890'

# Set the http_proxy and https_proxy environment variables
os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'
class GeminiModel():
    def __init__(
                self,
                model_name: str,
                api_key: str,
                temperature: float,
                **kwargs):
            genai.configure(api_key="AIzaSyB64nJyf2YD6UdRuyWGCrCYOkwCA5Yrxbw")
            genai.GenerationConfig(
                temperature=temperature
            )
            self.model = genai.GenerativeModel("gemini-1.5-pro")
            self.temperature = temperature
            self.api_key="AIzaSyBtIKNHDQpOePN4poQhD0iRQRQSmQi27wo"
            self.batch_forward_func = self.batch_forward_chatcompletion_palm

    def batch_forward_chatcompletion_palm(self, batch_prompts,batch_size):
            """
            Input a batch of prompts to PaLM chat API and retrieve the answers.
            """
            responses = []
            for i in range(batch_size):
                response = self.generate(prompt=batch_prompts)
                responses.append(response)
            return responses

    def generate(self, prompt):
            return self.model.generate_content(prompt).text