import re
from datasets import load_dataset
from .base_task import BaseTask
import numpy as np
import json
import random
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from numba import jit
import pickle as pkl
import sys
import types
import warnings
import numpy as np
import time
import os
import types
import warnings
import sys
import importlib
import random
import logging
from .gen_inst import TSPInstance, load_dataset
from .gls import guided_local_search
import time
import elkai
from tqdm import tqdm

def convert_to_int(value):
    try:
        return int(value)
    except ValueError:
        return None
def save_solution_to_json(data, solution_data, filename='solution.json'):
    output_data = {
        'locations': data['locations'],
        'solution': solution_data
    }
    with open(filename, 'w') as f:
        json.dump(output_data, f, indent=4)
class CustomTask(BaseTask):
    def __init__(self,
                 train_size,
                 eval_size,
                 test_size=None,
                 task_name='tsp',
                 task_discription="",
                 seed=None,
                 post_instruction=True,
                 **kwargs):
        super().__init__(task_name=task_name,
                         task_discription=task_discription,
                         seed=seed,
                         train_size=train_size,
                         eval_size=eval_size,
                         test_size=test_size,
                         post_instruction=post_instruction,
                         )
        self.answer_format_prompt = f"""
            The output of the routes in the following format example :
            <<start>>
            """
        self.answer_format_prompt += f"Salesman: 0-1-2-3-4-5-6-7-8-9-10-11-12-13-14\n"
        self.answer_format_prompt += "<<end>>\n\n"
        """
            answer_format_prompt: 
                It is appended after the task question to help the model extract the prediction.
                It should match your prediction extraction method in function "clean_response".
        """
        self.ndelay = 1
        self.problem_size = 200
        self.neighbor_size = np.minimum(200, self.problem_size)
        self.n_instance = 64
        self.running_time = 10
        self.old_route_set = set()
        self.distance_set=set()
        self.old_route_str=[]
    def load_task_dataset(self, data_dir):
        '''
            <task specific>
        '''
        with open('./src/tsp.json', 'r') as file:
            json_data = json.load(file)
        self.task_description = json_data['description']
        return json_data

    def transform_format(self, data):
        original_examples = data['examples']
        examples = []
        # Extracting input and target scores
        for example in original_examples:
            question = example['input']
            # Formatting the output
            formatted_example = {
                'question': question
            }
            examples.append(formatted_example)
        return examples
    def clean_response(self,response):
        function_pattern = r"```python(.*?)```"
        algorithm_str = re.search(r'<start>(.*?)<end>', response, re.DOTALL)
        matches = re.findall(function_pattern, response, re.DOTALL)
        if matches:
            extracted_function = matches[0].strip()
        else:
            extracted_function = ""
            return 0,extracted_function
        gap=self.evaluate(extracted_function)
        if gap==None:
            return 0,extracted_function
        return 1-gap,extracted_function
    def cal_metric(self, preds):
        '''
        <task specific>
        Calculate the evaluation metric, e.g. Accuracy, F1 score.
        "question" is for NCBI calculating F1 score.
        return a number / tuple of metrics

        This function is for calculating the reward of MCTS.
        '''
        correct = self.cal_correct(preds=preds)
        a=0
        for i in range(len(correct)):
            if correct[i]!=0:
                a+=np.array(preds)[i]
        a=a/len(correct)
        return a
    def cal_reward(self, preds, questions=None):
        '''
        <task specific>
        Calculate the evaluation metric, e.g. Accuracy, F1 score.
        "question" is for NCBI calculating F1 score.
        return a number / tuple of metrics

        This function is for calculating the reward of MCTS.
        '''
        correct = self.cal_correct(preds=preds)
        a=[]
        for i in range(len(correct)):
            if correct[i]!=0:
                a.append(np.array(preds)[i])
            else:
                a.append(0)
        return a
    def cal_correct(self, preds, data_type="str"):
        '''
        <task specific>
        The function of comparing the predictions and labels.

        data_type: str | set
            str: preds, labels are List(str)
            set: preds, labels are List(set)

        Every time a batch data is sampled and predicted, by comparing with
        the labels, PromptAgent collect the errors.
        Function called at: prompt_optim_agent/world_model/gradient_descent.py line 54

        '''
        if data_type == "set":
            comparisons = []
            for p, l in zip(preds):
                if p == l:
                    comparisons.append(1)
                else:
                    comparisons.append(0)
                return comparisons
        else:
            return list(np.array((np.array(preds) != 0)).astype(int))

    def tour_cost(self, instance, solution, problem_size):
        cost = 0
        for j in range(problem_size - 1):
            cost += np.linalg.norm(instance[int(solution[j])] - instance[int(solution[j + 1])])
        cost += np.linalg.norm(instance[int(solution[-1])] - instance[int(solution[0])])
        return cost

    def generate_neighborhood_matrix(self, instance):
        instance = np.array(instance)
        n = len(instance)
        neighborhood_matrix = np.zeros((n, n), dtype=int)

        for i in range(n):
            distances = np.linalg.norm(instance[i] - instance, axis=1)
            sorted_indices = np.argsort(distances)  # sort indices based on distances
            neighborhood_matrix[i] = sorted_indices

        return neighborhood_matrix

    def evaluation(self,function):
        problem_size = 200
        optimal_objs_dict = {20: 3.8039483761359274, 50: 5.754330442860288, 100: 7.726043475790581, 200: 10.695986353812152}
        dataset_path = f"./src/tasks/dataset/val{problem_size}_dataset.npy"
        dataset = load_dataset(dataset_path)
        objs = []
        durations = []
        for instance in dataset:
            obj, duration = self.solve(instance, function)
            objs.append(obj)
            durations.append(duration)
            mean_obj = np.mean(objs).item()
            mean_optimal_obj = optimal_objs_dict[problem_size]
            gap = mean_obj / mean_optimal_obj - 1
        return gap
    def calculate_cost(self,inst: TSPInstance, path: np.ndarray):
        return inst.distmat[path, np.roll(path, 1)].sum().item()
    def solve(self,inst: TSPInstance, heuristics):
        perturbation_moves_map = {
            20: 5,
            50: 30,
            100: 40,
            200: 40,
        }
        iter_limit_map = {
            20: 73,
            50: 175,
            100: 1800,
            200: 800,
        }
        start_time = time.time()
        heu = heuristics.heuristics(inst.distmat.copy())
        result = guided_local_search(inst.distmat, heu, perturbation_moves_map[inst.n], iter_limit_map[inst.n])
        duration = time.time() - start_time
        return self.calculate_cost(inst, result), duration
    def evaluate(self, code_string):
        try:
            # Suppress warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                # Create a new module object
                heuristic_module = types.ModuleType("heuristic_module")
                # Execute the code string in the new module's namespace
                exec(code_string, heuristic_module.__dict__)
                # Add the module to sys.modules so it can be imported
                sys.modules[heuristic_module.__name__] = heuristic_module
                # Now you can use the module as you would any other
                fitness = self.evaluation(heuristic_module)
                return fitness
        except Exception as e:
            # print("Error:", str(e))
            return None
perturbation_moves_map = {
        20: 5,
        50: 30,
        100: 40,
        200: 40,
    }
iter_limit_map = {
        20: 73,
        50: 175,
        100: 1800,
        200: 800,
    }
SCALE = 1000000
test_sizes = list(iter_limit_map.keys())


def calculate_cost(inst: TSPInstance, path: np.ndarray):
    return inst.distmat[path, np.roll(path, 1)].sum().item()
optimal_objs_dict = {20: 3.8039483761359274, 50: 5.754330442860288, 100: 7.726043475790581, 200: 10.695986353812152}

def solve(inst: TSPInstance, heuristics):
    start_time = time.time()
    heu = heuristics(inst.distmat.copy())
    result = guided_local_search(inst.distmat, heu, perturbation_moves_map[inst.n], iter_limit_map[inst.n])
    duration = time.time() - start_time
    return calculate_cost(inst, result), duration