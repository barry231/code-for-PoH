

## Quick Start

**Note**: Before running this command, please add your (OpenAI) api key to the example_config.yaml file (base_model_setting: api_key and optim_model_setting: api_key). You can also check all the other auguments in the yaml file.
```bash
python src/main.py --config_dir example_config.yaml 
```
The task setting is in example_config.yaml