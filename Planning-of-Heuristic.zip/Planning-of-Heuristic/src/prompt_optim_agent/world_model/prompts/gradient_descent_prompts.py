# These prompts are modified based on Automatic Prompt Optimization with "Gradient Descent" and Beam Search
# https://arxiv.org/abs/2305.03495

gradient_prompt_tempelate = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
My current heuristics is:
{cur_algorithm}
But this heuristics can't work:
{example_string}
For each wrong example, carefully examine each question and wrong answer step by step, 
provide comprehensive and different reasons why the heuristics leads to the wrong answer. 
At last, based on all these reasons, summarize and list all the aspects that can improve the heuristics.
""".strip()

optimize_prompt_tempelate = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
Here are some algorithm and the corresponding code and the reward, but the code can't work:
{example_string}
Based on these examples, the improvement of suggestion with this algorithm and the reasons are:
{gradient}
There are a list of former algorithms including the current heuristics, and each algorithm is modified from its former algorithms,the reward higher the algorithm better:
{trajectory_prompts}
Based on the above information, Please help me design a new heuristic that is different from the given ones
but can be motivated by them.
Firstly, identify the common idea in the provided heuristics.
Secondly, based on the backbone idea describe your new heuristic in one
sentence. The description must start with ‘<start>’ and end with ‘<end>’. 
Thirdly, implement it in Python as a function named ’heuristics’.The `heuristics` function takes as input a distance matrix, and returns prior indicators of how bad it is to include each edge in a solution. The return is of the same shape as the input.
All inputs and outputs are Numpy arrays. Do not give additional explanations.
""".strip()

example_template = """
<{index}> 
The heuristics code is:
{algorithm}
The heuristics's reward is: {reward}.
"""
optimize_prompt_tempelate_single = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
Here are some algorithm and the corresponding code and the reward, but the code can't work:
{example_string}
Based on these examples, the improvement of suggestion with this algorithm and the reasons are:
{gradient}
There are a list of former algorithms including the current heuristics, and each algorithm is modified from its former algorithms,the reward higher the algorithm better:
{trajectory_prompts}
Based on the above information, Please help me design a new heuristic that is different from the given ones
but can be motivated by them.
Firstly, identify the common idea in the provided heuristics.
Secondly, based on the backbone idea describe your new heuristic in one
sentence. The description must start with ‘<start>’ and end with ‘<end>’. 
Thirdly, implement it in Python as a function named ’heuristics’.The `heuristics` function takes as input a distance matrix, and returns prior indicators of how bad it is to include each edge in a solution. The return is of the same shape as the input.
All inputs and outputs are Numpy arrays. Do not give additional explanations.
""".strip()

ascend_gradient_prompt_tempelate = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
My current heuristics is:
{cur_algorithm}
This heuristics is not good enough:
{example_string}
For each example, the reward higher the heuristics better, identify the common idea in the provided heuristics. At last, based on all these reasons, summarize and list all the aspects that can improve the the heuristics.
""".strip()

ascend_optimize_prompt_tempelate = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
Here are some algorithm and the corresponding code and the reward is:
{example_string}
Based on these examples, the improvement of suggestion with this heuristic and the reasons are:
{gradient}
There are a list of former algorithms including the current heuristics, and each prompt is modified from its former algorithms,the reward higher the algorithm better:
{trajectory_prompts}
Based on the above information, Please help me design a new heuristic that is different from the given ones
but can be motivated by them.
Firstly, identify the common idea in the provided heuristics.
Secondly, based on the backbone idea describe your new heuristic in one
sentence. The description must start with ‘<start>’ and end with ‘<end>’. 
Thirdly, implement it in Python as a function named ’heuristics’.The `heuristics` function takes as input a distance matrix, and returns prior indicators of how bad it is to include each edge in a solution. The return is of the same shape as the input.
All inputs and outputs are Numpy arrays. Do not give additional explanations.
""".strip()

ascend_optimize_prompt_tempelate_single = """
You are an expert in the domain of optimization heuristics . Your task is to give hints to design better heuristics.
Here are some algorithm and the corresponding code and the reward is:
{example_string}
Based on these examples, the improvement of suggestion with this heuristic and the reasons are:
{gradient}
There are a list of former algorithms including the current heuristics, and each heuristic is modified from its former heuristics,the reward higher the heuristic better,:
{trajectory_prompts}
Based on the above information, Please help me design a new heuristic that is different from the given ones
but can be motivated by them.
Firstly, identify the common idea in the provided heuristics.
Secondly, based on the backbone idea describe your new heuristic in one
sentence. The description must start with ‘<start>’ and end with ‘<end>’. 
Thirdly, implement it in Python as a function named ’heuristics’.The `heuristics` function takes as input a distance matrix, and returns prior indicators of how bad it is to include each edge in a solution. The return is of the same shape as the input.
All inputs and outputs are Numpy arrays. Do not give additional explanations.
""".strip()