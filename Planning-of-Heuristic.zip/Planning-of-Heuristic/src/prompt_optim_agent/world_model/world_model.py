from .gradient_descent import *
from typing import Generic
from ..search_algo.base_algo import State, Action
from ..search_algo.mcts import MCTSNode
from tqdm import tqdm
import torch
import numpy as np
import ast
class WorldModel(Generic[State, Action]):
    def __init__(self,
                 task,
                 logger,
                 
                 base_model: str,
                 optim_model: str,
                 num_new_prompts = 1,
                 
                 train_shuffle = True,
                 train_batch_size: int = 5,
                 test_batch_size: int = 1,
                 eval_batch_size: int = 1,
                 print_log: bool = True,
                 **kwargs) -> None:
        
        """
        WorldModel is responsible for:
            State transition (generate new prompt based on the given node and batch data);
            Calculating reward for the given nodes;
            Calculating test metric on the test dataset.
        """
        
        self.task = task
        self.logger = logger
        self.base_model = base_model
        self.optim_model = optim_model
        self.num_new_prompts = num_new_prompts
        self.init_prompt = f"""
            You are an expert in the domain of optimization heuristics. Your task is to design heuristics that help designing a novel score function that scoring a set of bins to assign an item. \
In each step, the item will be assigned to the bin with the maximum score. If the rest capacity of a bin equals the maximum capacity, it will not be used. The final goal is to minimize the number of used bins.\
Firstly,describe your new heuristic in one
sentence. The description must start with ‘<start>’ and end with ‘<end>’. 
Next, implement it in Python as a function named ’score’.The `score` function takes two inputs: ’item’ and ’bins’. The function
should return one output: ’scores’.'item' and 'bins' are the size of current item and the rest capacities of feasible bins, which are larger than the item size. \
The output named 'scores' is the scores for the bins for assignment. Note that 'item' is of type int, while 'bins' and 'scores' are both Numpy arrays. The novel function should be sufficiently complex in order to achieve better performance. It is important to ensure self-consistency.
            """
        self.train_shuffle = train_shuffle
        self.train_batch_size = train_batch_size
        self.test_batch_size = test_batch_size
        self.eval_batch_size = eval_batch_size
        
        self.train_dataloader = self.task.get_dataloader('train', 
                                                        batch_size=train_batch_size, 
                                                        shuffle=train_shuffle)
        self.train_data_iterator = self._infinite_data_loader(self.train_dataloader)
        
        self.test_dataloader = self.task.get_dataloader('test', 
                                                        batch_size=test_batch_size, 
                                                        shuffle=False)
        self.eval_dataloader = self.task.get_dataloader('eval', 
                                                        batch_size=eval_batch_size, 
                                                        shuffle=False)
        self.gradient_descent = GradientDescent(
            task=self.task, 
            logger=self.logger, 
            base_model=base_model, 
            optim_model=optim_model, 
            num_new_prompts = num_new_prompts,
            print_log=print_log
            )
        
        self.log_vars()
        
    def log_vars(self):
        """
        Log world_model arguments.
        """
        self.logger.info('----------------- World Model --------------------------')
        ignored_print_vars = ['task', 'logger', 'train_dataloader','train_data_iterator','test_dataloader','eval_dataloader', 'gradient_descent']
        vars_dict = vars(self)
        for var_name in vars_dict:
            if var_name in ignored_print_vars: continue
            var_value = vars_dict[var_name]
            self.logger.info(f'{var_name} : {var_value}')
        
    def _infinite_data_loader(self, data_loader):
        """
        Yield batches from dataloader.
        """
        while True:
            for batch in data_loader:
                yield batch
                
    def get_train_batch(self):
        return next(self.train_data_iterator)
    
    def _get_trajectory_algorithm(self, node: MCTSNode):
        """
        Collect the trajectory of prompts from the root node to the given node.
        """
        trajectory_algorithm = []
        temp_node = node
        while True:
            trajectory_algorithm.append(temp_node.algorithm)
            if temp_node.parent is not None:
                temp_node = temp_node.parent
            else:
                break
        return trajectory_algorithm[::-1]
    
    def build_root(self, init_algorithm):
        """
        Build root MCTSNode using the initial prompt
        """
        node = MCTSNode(algorithm=init_algorithm, action=None, parent=None)
        node.reward = self._reward_type_helper(self.evaluate_algorithm(algorithm=node.algorithm)["metric"])
        return node
    
    def step(self, node:MCTSNode, batch):
        """
        Optimization step: 
            Generate new nodes based on the given node and batch of data.
        """
        new_nodes, gradient_descent_output = self._gradient_descent_step(node=node, batch=batch)
        return new_nodes, gradient_descent_output

    def _gradient_descent_step(self, node: MCTSNode, batch):
        trajectory_algorithm = self._get_trajectory_algorithm(node=node)
        helper_data = dict(trajectory_algorithm=trajectory_algorithm)
        gradient_descent_output = self.gradient_descent(batch, node.algorithm, helper_data)
        new_nodes = []
        for algorithm in gradient_descent_output['optimized_prompts']:
            child_node = MCTSNode(
                algorithm=algorithm,
                action=gradient_descent_output['optimized_prompts'],
                parent=node)
            new_nodes.append(child_node)
        
        return new_nodes, gradient_descent_output
        
    def evaluate_child_node(self, node:MCTSNode):
        """
        Evaluate the given node on eval_dataloader to calculate the reward.
        """
        evaludate_output = self.evaluate_algorithm(algorithm=node.algorithm)
        node.reward = self._reward_type_helper(evaludate_output["metric"])

    def evaluate_algorithm(self, algorithm):
        """
        Evaluate algorithm on eval_dataloader to calculate the reward.
        """
        alg=[]
        self.logger.info(f'algorithm: {algorithm}')
        alg.append(algorithm)
        metric, eval_output = self.eval_algorithm_with_loader(
            task=self.task, 
            eval_algorithms=alg,
            dataloader=self.eval_dataloader,
            )
        
        correct = eval_output['correct']
        evaludate_output = dict(
            metric=metric,
            correct = correct,
            acc = np.mean(correct)
        )
        return evaludate_output
    
    def test_algorithm(self, algorithm):
        """
        Test prompt on test_dataloader.
        """
        alg=[]
        alg.append(algorithm)
        metric, eval_output = self.eval_algorithm_with_loader(
            task=self.task, 
            eval_algorithms=alg,
            dataloader=self.test_dataloader,
            )
        return metric, eval_output

    def eval_instruction_with_loader(self, task, eval_prompt, dataloader, record_outputs=True):
        """
        Evaluate eval_prompt on the given dataloader.
        Output:
            metric: task specific evaluation metric, e.g. Accuracy
            eval_output: the input question and predictions for each example in the dataloader
        """
        build_forward_prompts_func = task.build_forward_prompts_completion
        batch_forward_func = self.base_model.batch_forward_func
        all_questions = []
        all_preds = []
        all_prompts = []
        all_responses = []
        eval_output = {}
        pbar = tqdm(dataloader, leave=False)
        for batch in pbar:
            batch_prompts = build_forward_prompts_func(batch['question'], eval_prompt)
            batch_size = len(batch['question'])
            responses = batch_forward_func(batch_prompts, batch_size)
            preds, algorithm= task.batch_clean_response(responses)
            all_preds.extend(preds)
            all_questions.extend(batch['question'])
            if record_outputs:
                all_prompts.extend(batch_prompts)
                all_responses.extend(responses)
            metric = task.cal_metric(all_preds, all_questions)
            if not isinstance(metric, tuple):
                pbar.set_postfix_str(f"Test Metric: {metric:.4f}")
            else:
                pbar.set_postfix_str(f"Test Metrics: {metric}")

        if record_outputs:
            eval_output['model_inputs'] = all_prompts
            eval_output['model_responses'] = all_responses
            eval_output['preds'] = all_preds
        eval_output['correct'] = task.cal_correct(all_preds)
        metric = task.cal_metric(all_preds, all_questions)
        return metric, eval_output
    def eval_algorithm_with_loader(self, task, eval_algorithms, dataloader, record_outputs=True):
        """
        Evaluate eval_prompt on the given dataloader.
        Output:
            metric: task specific evaluation metric, e.g. Accuracy
            eval_output: the input question and predictions for each example in the dataloader
        """
        all_preds = []
        all_algorithms = []
        all_responses = []
        eval_output = {}
        pbar = tqdm(dataloader, leave=False)
        for batch in pbar:
            batch_size = len(batch['question'])
            preds, algorithm= task.batch_clean_response(eval_algorithms)
            all_preds.extend(preds)
            if record_outputs:
                all_algorithms.extend(algorithm)
            metric = task.cal_metric(all_preds)
            if not isinstance(metric, tuple):
                pbar.set_postfix_str(f"Test Metric: {metric:.4f}")
            else:
                pbar.set_postfix_str(f"Test Metrics: {metric}")

        if record_outputs:
            eval_output['model_inputs'] = all_algorithms
            eval_output['model_responses'] = all_responses
            eval_output['preds'] = all_preds
        eval_output['correct'] = task.cal_correct(all_preds)
        metric = task.cal_metric(all_preds)
        return metric, eval_output
    def _reward_type_helper(self, metric):
        if isinstance(metric, tuple):
            return metric[0]
        else:
            return metric
