import requests
import time
from zhipuai import ZhipuAI

class glmModel():
    def __init__(
            self,
            model_name: str,
            api_key: str,
            temperature: float,
            **kwargs):

        self.api_key =  "1e879bc88db45902db80c6c64aef6bac.nwitYXIB6JfwujLq"

        self.model = model_name
        self.temperature = temperature

        self.batch_forward_func = self.batch_forward_chatcompletion
        self.generate = self.gpt_chat_completion

    def batch_forward_chatcompletion(self, batch_prompts,batch_size):
        """
        Input a batch of prompts to ZhiPu AI chat API and retrieve the answers.
        """
        responses = []
        for i in range(batch_size):
            response = self.gpt_chat_completion(prompt=batch_prompts)
            responses.append(response)
        return responses

    def gpt_chat_completion(self, prompt):
        backoff_time = 1
        messages = [{"role": "user", "content": prompt}, ]
        while True:
            client = ZhipuAI(api_key=self.api_key)
            return client.chat.completions.create(
                    messages=messages,
                    temperature=self.temperature,
                    model=self.model).choices[0].message.content.strip()


